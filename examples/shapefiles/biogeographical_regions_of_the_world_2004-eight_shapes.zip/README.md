# Updates from the original file

Per the Terms of Use (copied below) of the original file, we here describe the manner in which this shapefile differs from the original.

The shapefile files in this zip file are an adjusted version of the shapefile 'Biogeographical Realms of the World (2004)' downloaded from (https://data-gis.unep-wcmc.org/portal/home/item.html?id=f196d94a226d430fa214947d51dad35a) on 11/28/2025.

The adjustments made were:
* merge the two Nearctic polygons into a single Nearctic multi-polygon
* Do the same for the 2 Oceanic polygons and the 2 Palearctic polygons.

In each case polygons had been split across the prime-meridian. The change here does *not* union the two polygons across their common prime-meridian boundary, it merely puts the two existing separate polygons together into one multi-polygon consisting of the two original sub polygons. The change was made using QGis.

# The original Terms of Use
From https://data-gis.unep-wcmc.org/portal/home/item.html?id=f196d94a226d430fa214947d51dad35a :
This data is available for use for valid scientific, conservation, and educational purposes.
Any modification of the original map by users to ecoregion boundaries, units, names, or realm and biome classes must be noted.

# The original Description
From https://data-gis.unep-wcmc.org/portal/home/item.html?id=f196d94a226d430fa214947d51dad35a :
This map is a simplified representation of the eight Biogeographical Realms of the world. This global map provides a useful general framework for conducting biogeographical or macroecological research. The realms are based originally on ecoregion delineations on hundreds of previous biogeographical studies, and refined and synthesized existing information in regional workshops over 10 years to assemble the global dataset. Ecoregions were then nested within two higher-order classifications to produce biomes (14) and biogeographic realms (8). Together, these nested classification levels provide a framework for comparison among units and the identification of representative habitats and species assemblages.

This is an update to version 1.0  of the Simplified Biogeographical Realms of the World dataset which was generalised from  Olson, D.M., E. Dinerstein, E.D. Wikramanayake, N.D. Burgess, G.V.N. Powell, E.C. Underwood, J.A. D'Amico, I. Itoua, H.E. Strand, J.C. Morrison, C.J. Loucks, T.F. Allnutt, T.H. Ricketts, Y. Kura, J.F. Lamoreux, W.W. Wettengel, P. Hedao, and K.R. Kassem. Terrestrial Ecoregions of the World: A New Map of Life on Earth (PDF, 1.1M) BioScience 51:933-938. Subsequently modified and extended at UNEP-WCMC (2011).